from django.contrib import admin

from report.models import *

admin.site.register(ReportRequest)
admin.site.register(ReportDefinition)
# Register your models here.
